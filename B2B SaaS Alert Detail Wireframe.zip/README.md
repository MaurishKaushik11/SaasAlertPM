
  # B2B SaaS Alert Detail Wireframe

  This is a code bundle for B2B SaaS Alert Detail Wireframe. The original project is available at https://www.figma.com/design/QM1Uz9JRrLH8ChYsQ5ulwz/B2B-SaaS-Alert-Detail-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
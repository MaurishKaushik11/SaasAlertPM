export function AlertDetailWireframe() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header Section */}
      <header className="border-b-2 border-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h1 className="mb-2">Unusual IAM Permission Escalation Detected</h1>
              <p className="text-gray-600">
                User account granted elevated administrative privileges outside normal workflow
              </p>
            </div>
            <div className="ml-6 flex gap-3">
              <span className="border-2 border-gray-900 px-4 py-2 bg-gray-900 text-white">
                HIGH
              </span>
              <span className="border-2 border-gray-900 px-4 py-2">
                NEW
              </span>
            </div>
          </div>
          <div className="text-gray-500">
            Detected: 2026-01-05 14:32:18 UTC (8 minutes ago)
          </div>
        </div>
      </header>

      {/* Main Content - Two Column Layout */}
      <main className="max-w-7xl mx-auto p-6 pb-32">
        <div className="grid grid-cols-2 gap-6">
          {/* Left Column - Alert Summary & Resource Details */}
          <div className="space-y-6">
            {/* Alert Summary */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>What Happened</h2>
              </div>
              <p className="mb-4 leading-relaxed">
                A service account <span className="bg-gray-200 px-1">svc-analytics-prod</span> was
                granted PowerUserAccess and IAMFullAccess policies. This account typically has
                read-only permissions for data processing tasks.
              </p>
              <p className="leading-relaxed">
                The permission change was made via the AWS Console by user{' '}
                <span className="bg-gray-200 px-1">john.smith@company.com</span> from IP address
                203.0.113.42 (outside corporate network range).
              </p>
            </section>

            {/* Why This Matters */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>Why This Matters</h2>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="mr-2 mt-1">□</span>
                  <span>Privilege escalation can lead to unauthorized access to sensitive resources</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 mt-1">□</span>
                  <span>Service account has access to production customer data pipelines</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 mt-1">□</span>
                  <span>Activity originated from non-corporate IP address</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2 mt-1">□</span>
                  <span>Violates least privilege principle and internal security policy</span>
                </li>
              </ul>
            </section>

            {/* Affected Resource */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>Affected Resource Details</h2>
              </div>
              <div className="space-y-3">
                <div className="grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-600">Resource ID:</div>
                  <div className="bg-gray-100 px-2 py-1 font-mono">svc-analytics-prod</div>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-600">Resource Type:</div>
                  <div>IAM Service Account</div>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-600">Cloud Account:</div>
                  <div>production-data-analytics (AWS 123456789012)</div>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-600">Region:</div>
                  <div>us-east-1</div>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-2">
                  <div className="text-gray-600">Created:</div>
                  <div>2024-03-15</div>
                </div>
              </div>
            </section>

            {/* Annotation */}
            <div className="border-l-4 border-gray-400 pl-4 py-2 text-gray-600 text-sm">
              <strong>Design Note:</strong> Plain-language explanation reduces cognitive load. Engineers
              can quickly understand "what" and "why" without parsing technical logs first.
            </div>
          </div>

          {/* Right Column - Context & Investigation */}
          <div className="space-y-6">
            {/* Recent Changes */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>Recent Changes (Last 7 Days)</h2>
              </div>
              <div className="space-y-4">
                <div className="pb-3 border-b border-gray-300">
                  <div className="text-sm text-gray-500 mb-1">2026-01-05 14:32 UTC</div>
                  <div>AttachUserPolicy: PowerUserAccess</div>
                  <div className="text-sm text-gray-600 mt-1">
                    By: john.smith@company.com | IP: 203.0.113.42
                  </div>
                </div>
                <div className="pb-3 border-b border-gray-300">
                  <div className="text-sm text-gray-500 mb-1">2026-01-05 14:31 UTC</div>
                  <div>AttachUserPolicy: IAMFullAccess</div>
                  <div className="text-sm text-gray-600 mt-1">
                    By: john.smith@company.com | IP: 203.0.113.42
                  </div>
                </div>
                <div className="pb-3">
                  <div className="text-sm text-gray-500 mb-1">2026-01-02 09:15 UTC</div>
                  <div>UpdateAccessKey: Created new access key</div>
                  <div className="text-sm text-gray-600 mt-1">
                    By: svc-analytics-prod | IP: 10.0.45.123
                  </div>
                </div>
              </div>
            </section>

            {/* Similar Historical Alerts */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>Similar Historical Alerts</h2>
              </div>
              <div className="space-y-4">
                <div className="pb-3 border-b border-gray-300">
                  <div className="flex justify-between items-start mb-1">
                    <div>IAM Permission Escalation</div>
                    <div className="bg-gray-200 px-2 py-1 text-xs">FALSE POSITIVE</div>
                  </div>
                  <div className="text-sm text-gray-600">
                    2025-12-15 | svc-reporting | Authorized change by SecOps team
                  </div>
                </div>
                <div className="pb-3 border-b border-gray-300">
                  <div className="flex justify-between items-start mb-1">
                    <div>Unusual Admin Access</div>
                    <div className="bg-gray-900 text-white px-2 py-1 text-xs">CONFIRMED THREAT</div>
                  </div>
                  <div className="text-sm text-gray-600">
                    2025-11-08 | svc-data-export | Compromised credentials, revoked
                  </div>
                </div>
                <div className="pb-3">
                  <div className="flex justify-between items-start mb-1">
                    <div>Service Account Policy Change</div>
                    <div className="bg-gray-200 px-2 py-1 text-xs">FALSE POSITIVE</div>
                  </div>
                  <div className="text-sm text-gray-600">
                    2025-10-22 | svc-analytics-dev | Approved maintenance window
                  </div>
                </div>
              </div>
            </section>

            {/* Reference Links */}
            <section className="border-2 border-gray-900 p-5">
              <div className="mb-4 pb-2 border-b border-gray-400">
                <h2>Reference & Documentation</h2>
              </div>
              <div className="space-y-2">
                <div className="pb-2 border-b border-gray-200">
                  <a href="#" className="underline">
                    → IAM Best Practices: Least Privilege
                  </a>
                </div>
                <div className="pb-2 border-b border-gray-200">
                  <a href="#" className="underline">
                    → Service Account Security Policy (Internal)
                  </a>
                </div>
                <div className="pb-2 border-b border-gray-200">
                  <a href="#" className="underline">
                    → Incident Response Playbook: Privilege Escalation
                  </a>
                </div>
                <div className="pb-2">
                  <a href="#" className="underline">
                    → AWS CloudTrail Logs (Direct Link)
                  </a>
                </div>
              </div>
            </section>

            {/* Annotation */}
            <div className="border-l-4 border-gray-400 pl-4 py-2 text-gray-600 text-sm">
              <strong>Design Note:</strong> Historical context and similar outcomes help engineers
              pattern-match and make faster decisions based on organizational knowledge.
            </div>
          </div>
        </div>
      </main>

      {/* Sticky Footer - Primary Actions */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t-4 border-gray-900 p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Next steps: Choose an action to begin your investigation or close this alert
          </div>
          <div className="flex gap-4">
            <button className="border-2 border-gray-400 px-6 py-3 hover:bg-gray-100">
              Mark as False Positive
            </button>
            <button className="border-2 border-gray-900 px-6 py-3 hover:bg-gray-100">
              Proceed to Remediation
            </button>
            <button className="border-2 border-gray-900 bg-gray-900 text-white px-6 py-3 hover:bg-gray-800">
              Start Investigation
            </button>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-4 border-l-4 border-gray-400 pl-4 py-2 text-gray-600 text-sm">
          <strong>Design Note:</strong> Sticky footer with clear CTAs ensures actions are always visible.
          Primary action (Start Investigation) uses highest contrast. All decisions can be made without
          scrolling or switching tools.
        </div>
      </footer>
    </div>
  );
}
